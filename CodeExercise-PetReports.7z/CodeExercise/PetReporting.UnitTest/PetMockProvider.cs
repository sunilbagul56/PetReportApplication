﻿using PetReporting.API.Contracts;
using PetReporting.API.Model;
using System;
using System.Collections.Generic;

namespace PetReporting.UnitTest
{
    public static class PetMockProvider
    {
        public static List<Pet> GetAllPets()
        {
            return new List<Pet>()
            {
                new Dog() { Owner = new Owner() { Firstname = "Jim", Lastname = "Rogers" }, NumberofVisits = 5, JoinedPractice = DateTime.Now},
                new Dog() { Owner = new Owner() { Firstname = "Tony", Lastname = "Smith" }, NumberofVisits = 10, JoinedPractice = new DateTime(1985, 7, 13)},
                new Cat() { Owner = new Owner() { Firstname = "Steve", Lastname = "Roberts" }, NumberofVisits = 20, JoinedPractice = new DateTime(2002, 5, 6), NumberOfLives = 9 }
            };
        }

        public static CreateReportRequest GetCreateReportRequest()
        {
            return new CreateReportRequest()
            {
                Pets = new List<Pet>()
                {
                    new Dog() { Owner = new Owner() { Firstname = "Jim", Lastname = "Rogers" }, NumberofVisits = 5, JoinedPractice = DateTime.Now},
                    new Dog() { Owner = new Owner() { Firstname = "Tony", Lastname = "Smith" }, NumberofVisits = 10, JoinedPractice = new DateTime(1985, 7, 13)},
                    new Cat() { Owner = new Owner() { Firstname = "Steve", Lastname = "Roberts" }, NumberofVisits = 20, JoinedPractice = new DateTime(2002, 5, 6), NumberOfLives = 9 }
                }
            };
        }
    }
}
