﻿using FluentAssertions;
using PetReporting.API.Contracts;
using PetReporting.API.Service;
using System.IO;
using Xunit;

namespace PetReporting.UnitTest.Service
{
    public class ReportServiceTest
    {
        public IReportService _reportService;

        public ReportServiceTest()
        {
            _reportService = new ReportService();
        }

        [Fact]
        public void GenerateReport_Creates_Pet_Report_Successfully()
        {
            //Arrange
            var pets = PetMockProvider.GetAllPets();

            //Act
            _reportService.GenerateReport(pets);
            var petsResult = File.ReadAllLines("PetsReport.csv");

            //Assert
            petsResult.Should().NotBeNullOrEmpty();
            petsResult.Should().HaveCountGreaterThan(1);
        }
    }
}
