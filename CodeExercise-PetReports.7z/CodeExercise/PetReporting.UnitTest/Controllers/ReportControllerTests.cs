﻿using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Moq;
using PetReporting.API.Contracts;
using PetReporting.API.Controllers;
using PetReporting.API.Model;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace PetReporting.UnitTest.Controllers
{
    public class ReportControllerTests
    {
        private readonly ReportController _reportController;
        private readonly Mock<IReportService> _reportService;

        public ReportControllerTests()
        {
            _reportService = new Mock<IReportService>();
            _reportController = new ReportController(_reportService.Object);
        }

        [Fact]
        public void GenerateReport_Creates_Pet_Report_Successfully()
        {
            //Arrange
            var createReportRequest = PetMockProvider.GetCreateReportRequest();
            _reportService.Setup(x => x.GenerateReport(It.IsAny<List<Pet>>())).Returns(Task.CompletedTask);

            //Act
            var response = _reportController.CreateReport(createReportRequest);

            //Assert
            response.Should().NotBeNull();
            Assert.IsType<OkResult>(response);
            _reportService.Verify(x => x.GenerateReport(It.IsAny<List<Pet>>()), Times.Once);
        }
    }
}
