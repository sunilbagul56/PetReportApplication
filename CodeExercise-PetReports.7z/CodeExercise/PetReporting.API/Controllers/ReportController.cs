﻿using Microsoft.AspNetCore.Mvc;
using PetReporting.API.Contracts;
using PetReporting.API.Extensions;
using System;

namespace PetReporting.API.Controllers
{
    [Route("report")]
    public class ReportController : ControllerBase
    {
        public IReportService _reportService;

        public ReportController(IReportService reportService)
        {
            _reportService = reportService ?? throw new ArgumentNullException(nameof(reportService));
        }

        [HttpPost("create")]
        public IActionResult CreateReport(CreateReportRequest createReportRequest)
        {
            //Validate request
            createReportRequest.EnsureNotNull(nameof(CreateReportRequest));
            createReportRequest.Pets.EnsureCollectionNotEmpty(nameof(CreateReportRequest.Pets));

            //Call report service to generate pets report
            _reportService.GenerateReport(createReportRequest.Pets);
            return Ok();
        }
    }
}
