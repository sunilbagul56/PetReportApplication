﻿
namespace PetReporting.API.Model
{
    public class Cat : Pet
    {
        public int? NumberOfLives { get; set; }
    }
}
