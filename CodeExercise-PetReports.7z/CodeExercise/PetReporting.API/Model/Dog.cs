﻿
namespace PetReporting.API.Model
{
    public class Dog : Pet
    {
    }
}
