﻿using System;

namespace PetReporting.API.Model
{
    public class Pet
    {
        public Owner Owner { get; set; }
        public int NumberofVisits { get; set; }
        public double CostPerVisit { get; set; }
        public DateTime JoinedPractice { get; set; }
    }
}
