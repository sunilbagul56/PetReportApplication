﻿namespace PetReporting.API.Model
{
    public class Owner
    {
        public string Firstname { get; set; }
        public string Lastname { get; set; }
    }
}
