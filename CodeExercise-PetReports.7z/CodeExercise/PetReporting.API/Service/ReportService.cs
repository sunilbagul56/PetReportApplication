﻿using PetReporting.API.Contracts;
using PetReporting.API.Extensions;
using PetReporting.API.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PetReporting.API.Service
{
    public class ReportService : IReportService
    {
        public Task GenerateReport(IEnumerable<Pet> pets)
        {
            List<string> entries = new List<string>();
            entries.Add("Owners name, Date Joined Practice, Number Of Visits, Number of Lives");

            foreach (var p in pets)
            {
                var entry = $"{p.Owner?.Firstname} {p.Owner.Lastname} {p.JoinedPractice} {p.NumberofVisits}";
                if (p is Cat)
                {
                    var cat = p as Cat;
                    entry += "," + cat.NumberOfLives;
                }

                entries.Add(entry);
            }

            Helper.SaveDataAsync(entries);
            return Task.CompletedTask;
        }
    }
}
