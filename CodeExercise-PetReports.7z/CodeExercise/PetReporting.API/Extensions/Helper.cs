﻿using PetReporting.API.Contracts;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace PetReporting.API.Extensions
{
    public static class Helper
    {
        public static Task SaveDataAsync(List<string> tData)
        {
            File.WriteAllLines(KeyStore.CsvFileName, tData.ToArray());
            return Task.CompletedTask;
        }
    }
}
