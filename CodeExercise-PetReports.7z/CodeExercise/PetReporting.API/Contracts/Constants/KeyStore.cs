﻿namespace PetReporting.API.Contracts
{
    public static class KeyStore
    {
        public const string CsvFileName = "PetReport";
    }
}
