﻿using PetReporting.API.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PetReporting.API.Contracts
{
    public interface IReportService
    {
        Task GenerateReport(IEnumerable<Pet> pets);
    }
}
