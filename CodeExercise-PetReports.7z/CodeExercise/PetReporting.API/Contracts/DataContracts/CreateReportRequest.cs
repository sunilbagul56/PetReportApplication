﻿using PetReporting.API.Model;
using System.Collections.Generic;

namespace PetReporting.API.Contracts
{
    public class CreateReportRequest
    {
        public List<Pet> Pets { get; set; }
    }
}
